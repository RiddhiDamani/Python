#!/usr/bin/env python3
# Copyright 2009-2017 BHG http://bw.org/

x = 'Riddhi'
y = 'Hello {}'.format(x)

print('Hello, World.')
print('My name is Riddhi Damani')
print('Hello World {}'.format(x))
print(y)
print(f'Hello World {x}')
