# Python module to import

print("File two __name__ is set to: {}" .format(__name__))