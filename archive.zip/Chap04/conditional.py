#!/usr/bin/env python3
# Copyright 2009-2017 BHG http://bw.org/

if True:
    print('if true')
elif False:
    print('elif true')
else:
    print('neither true')
