#!/usr/bin/env python3
# Copyright 2009-2017 BHG http://bw.org/

x = 5
y = 3
z = x + y
a = x - y
b = x * y
c = x / y
d = x // y # Integer division - get the quotient
e = x % y # to get the remainder - modulus
e = -e # - and + is just for the decor, not going to do anything with the operand (value)

print(f'result is {z}')
print(f'result is {a}')
print(f'result is {b}')
print(f'result is {c}')
print(f'result is {d}')
print(f'result is {e}')
