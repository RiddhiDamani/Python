#!/usr/bin/env python3
# Copyright 2009-2017 BHG http://bw.org/

a = True
b = False
x = ('bear', 'bunny', 'tree', 'sky', 'rain')
y = 'bear'

#if a or b:
#if not b:
#if y not in x:
if y is x[0]:
    print('expression is true')
else:
    print('expression is false')
