# Python file one module

import file_two

print("File one __name__ is set to: {}" .format(__name__))


# Encapsulation is a mechanism of wrapping the data (variables) and
# code acting on the data (methods) together as a single unit.

# Data abstraction is the process of hiding certain details
# and showing only essential information to the user.

